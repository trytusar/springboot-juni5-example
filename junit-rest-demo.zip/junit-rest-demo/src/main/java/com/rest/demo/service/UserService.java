package com.rest.demo.service;

public interface UserService {
	
	public String getUserData(String emailId);
	
}
