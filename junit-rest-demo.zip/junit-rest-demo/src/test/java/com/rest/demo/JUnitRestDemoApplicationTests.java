package com.rest.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JUnitRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
